class Calculo {

  //atributos
  public int operador;
  public double valorUm;
  public double valorDois;
  
  Calculo(int operador, double valorUm, double valorDois)
  {
    this.operador = operador;
    this.valorUm = valorUm;
    this.valorDois = valorDois;
  }

  //metodo calcular
  public double calculador(int operador, double valorUm, double valorDois){

    double resultado = 0.0;
    switch (operador){
      case 0: resultado = valorUm + valorDois;
      break;
      case 1: resultado = valorUm - valorDois;
      break;
      case 2: resultado = valorUm * valorDois;
      break;
      case 3: resultado = valorUm / valorDois; //implementar a verificação de divisão por zero
           
    }
    return resultado;
  }

  
}