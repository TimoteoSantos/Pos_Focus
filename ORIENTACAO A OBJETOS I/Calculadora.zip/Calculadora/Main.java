import java.util.Scanner;

public class Main {
  
    public static void main(String[] args) {

      Scanner sc = new Scanner(System.in);
      /*
      CALCULADORA SIMPLES JAVA
      */

      System.out.println("ESCOLHA UMA OPÇÃO: 0 PARA ADICAO \n 1 PARA SUBTRACAO \n 2 PARA MULTIPLICACAO \n 3 PARA DIVISAO");
      int operador = sc.nextInt();
      
      System.out.println("DIGITE O PRIMEIRO VALOR");
      double valorUm = sc.nextDouble();
      
      System.out.println("DIGITE O SEGUNDO VALOR");
      double valorDois = sc.nextDouble();
      
      Calculo calculo = new Calculo(operador, valorUm, valorDois);
      
      double resultado = calculo.calculador(operador, valorUm, valorDois);
      System.out.println("O RESULTADO E: " + resultado);
      
    
    }
}