public class Main {
  public static void main(String[] args) {

    int codCliente = Cliente.id;

    Cliente  cliente = new Cliente("timoteo");    
    System.out.println(Cliente.id);

    Cliente  cliente2 = new Cliente("timoteo");    
    System.out.println(Cliente.id);

    Cliente  cliente3 = new Cliente("timoteo");    
    System.out.println(Cliente.id);

    Cliente  cliente4 = new Cliente("timoteo");    
    System.out.println(Cliente.id);    
  }

}