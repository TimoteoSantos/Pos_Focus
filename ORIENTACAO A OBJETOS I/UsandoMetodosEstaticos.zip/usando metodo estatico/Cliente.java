public class Cliente {
  public static int id;
  public static String nome;

  public Cliente(String nome) {
    this.nome = nome;
    // toda vez que eu criar um cliente eu incremento o id
    this.id += 1;
  }
}