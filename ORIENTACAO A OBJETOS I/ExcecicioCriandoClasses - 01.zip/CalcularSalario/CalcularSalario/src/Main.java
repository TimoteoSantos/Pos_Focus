import javax.swing.plaf.synth.SynthOptionPaneUI;
import  java.util.Scanner;

public class Main {

    public static void main(String[] args){

       Scanner sc = new Scanner(System.in);

    //criando um funcionario
    Funcionario funcionario = new Funcionario("timoteo","santos",34);
        System.out.println("***********************");
        System.out.println("GENTILEZA DIGITE SEU SALARIO");
    Pagamento pg = new Pagamento(sc.nextDouble());

    pg.CalcularDesconto();

        System.out.println("voce teve um salario de " +
                pg.getSalario() +
                " \n uma taxa de INSS DE " +
                pg.getTaxaInss() +
                "\n foi descontado do seu salario o valor de "+
                pg.CalcularDesconto()
        );
    }
}