abstract  public class Pessoa {

    //atributos de uma pessoa
    private String nome;
    private String sobrenome;
    private int idade;

    //metodo construtor
    Pessoa(String nome, String sobrenome, int idade){
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.idade = idade;
    }

    //getters e setters
    String getNome() {
        return nome;
    }

    String getSobrenome() {
        return sobrenome;
    }

    int getIdade() {
        return idade;
    }

    void setNome(String nome) {
        this.nome = nome;
    }

    void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    void setIdade(int idade) {
        this.idade = idade;
    }
}