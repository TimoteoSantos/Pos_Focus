public class Pagamento {

    private  double salario;
    private  double taxaInss;
    private  double desconto;

    //get e set
    public  double  getSalario(){
       return this.salario;
    }

    public void setSalario(double salario){
           this.salario = salario;
    }

    public void setTaxa(double taxa){
        this.taxaInss = taxa;
    }
    public double getTaxaInss(){
        return this.taxaInss;
    }

    Pagamento(double salario) {
        setSalario(salario);
    }
    public double CalcularDesconto() {

        if(this.salario <= 1000.00){
            this.setTaxa(0.080);
        } else if ((this.salario > 1000.00) && (this.salario <= 1500.00)) {
            this.setTaxa(0.085);
        } else {
            this.setTaxa(0.090);
        }
        return this.desconto = this.salario * this.taxaInss;
    }
}
