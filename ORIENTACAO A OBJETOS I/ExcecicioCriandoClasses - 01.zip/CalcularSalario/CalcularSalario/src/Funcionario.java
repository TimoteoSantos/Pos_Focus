public class Funcionario  extends  Pessoa{

    Funcionario (String nome, String sobrenome, int idade){
        super(nome,sobrenome,idade);
    }
}
